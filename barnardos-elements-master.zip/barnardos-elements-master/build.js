/**
 * Build script to assemble the entire project.
 * - Assemble and combine sass
 * - Compile sass to css
 * - Assemble js into library file and translate to ES5
 */
const fs = require('fs-extra')
const path = require('path')
const Q = require('q')
const sass = require('node-sass')

const sourcePath = `${__dirname}/src`
const sourceTopSassPath = `${sourcePath}/sass/barnardos-elements.scss`
const componentPath = `${__dirname}/src/components`

const distPath = `${__dirname}/dist`
const distSassPath = `${distPath}/sass`
const distCssPath = `${distPath}/css`
const distTopSassPath = `${distSassPath}/barnardos-elements.scss`
const distNunjucks = `${distPath}/nunjucks`

const relativeComponentSassPath = 'barnardos/components'

function walk (dir, done) {
  let results = []
  fs.readdir(dir, (err, list) => {
    if (err) return done(err)
    let pending = list.length
    if (!pending) return done(null, results)
    list.forEach(function (file) {
      file = path.resolve(dir, file)
      fs.stat(file, (err, stat) => {
        if (err) throw (err)
        if (stat && stat.isDirectory()) {
          walk(file, (err, res) => {
            if (err) throw (err)
            results = results.concat(res)
            if (!--pending) done(null, results)
          })
        } else {
          results.push(file)
          if (!--pending) done(null, results)
        }
      })
    })
  })
}

function clean () {
  console.log('Clean - Start')
  if (fs.existsSync(distPath)) {
    fs.removeSync(distPath)
  }

  fs.ensureDirSync(distSassPath)
  fs.ensureDirSync(distCssPath)
  console.log('Clean - End')
}

function getComponentStyleFiles (componentPath) {
  return new Promise((resolve) => {
    getComponentStyleFilesWithComponentPath(componentPath)
    .then((paths) => {
      const stripPaths = paths.map((path) => {
        const parts = path.split('/')
        return parts[parts.length - 1]
      })
      resolve(stripPaths)
    })
  })
}

function getComponentStyleFilesWithComponentPath (componentPath) {
  return new Promise((resolve, reject) => {
    walk(componentPath, (err, list) => {
      if (err) reject(err)

      resolve(
        list
          .filter(path => path.toLowerCase().endsWith('.scss'))
          .map(path => {
            const pathParts = path.split('/')
            return `${pathParts[pathParts.length - 2]}/${pathParts[pathParts.length - 1]}`
          })
      )
    })
  })
}

function combineSass () {
  console.log('Create master Sass file - Start')
  return new Promise((resolve, reject) => {
    Q.spawn(function * () {
      try {
        const topLevelFileStr = fs.readFileSync(sourceTopSassPath, 'utf8')
        const componentSassFileNames = yield getComponentStyleFiles(componentPath)

        // Tidy up the file names to import.
        const parsedSassFileNames = componentSassFileNames.map((componentSassFileName) => {
          if (componentSassFileName.charAt(0) === '_') {
            componentSassFileName = componentSassFileName.substr(1)
          }
          if (componentSassFileName.indexOf('.')) {
            componentSassFileName = componentSassFileName.substr(0, componentSassFileName.indexOf('.'))
          }

          return `@import "${relativeComponentSassPath}/${componentSassFileName}";`
        })

        // Build the top level sass file combining top level file and component imports
        fs.writeFileSync(distTopSassPath, `${topLevelFileStr}\n${parsedSassFileNames.join('\n')}`)
        console.log('Create master sass file - End')
        resolve()
      } catch (error) {
        reject(error)
      }
    })
  })
}

function copySassFiles () {
  return new Promise((resolve, reject) => {
    Q.spawn(function * () {
      try {
        console.log('Copy Sass files - Start')
        fs.ensureDirSync(`${distSassPath}/barnardos/components`)
        const componentSassFileNames = yield getComponentStyleFilesWithComponentPath(componentPath)
        for (const sassFileName of componentSassFileNames) {
          const pathParts = sassFileName.split('/')
          fs.copySync(`${componentPath}/${sassFileName}`, `${distSassPath}/barnardos/components/${pathParts[1]}`)
        }

        fs.copySync(`${sourcePath}/sass/barnardos`, `${distSassPath}/barnardos`)

        fs.ensureDirSync(`${distSassPath}/neat`)
        fs.copySync(`${__dirname}/node_modules/bourbon-neat/app/assets/stylesheets`, `${distSassPath}/neat`)

        console.log('Copy Sass files - end')
        resolve()
      } catch (exception) {
        reject(exception)
      }
    })
  })
}

function compileSass () {
  return new Promise((resolve, reject) => {
    console.log(`Compile CSS - Start`)
    try {
      const devCss = sass.renderSync({
        file: distTopSassPath,
        outFile: `${distCssPath}/barnardos-elements.css`,
        sourceMap: true,
        includePaths: [distSassPath]
      })
      fs.writeFileSync(`${distCssPath}/barnardos-elements.css`, devCss.css)

      const prodCss = sass.renderSync({
        file: distTopSassPath,
        outFile: `${distCssPath}/barnardos-elements.min.css`,
        includePaths: [distSassPath],
        outputStyle: 'compressed'
      })
      fs.writeFileSync(`${distCssPath}/barnardos-elements.min.css`, prodCss.css)
      console.log(`Compile CSS - End`)
      resolve()
    } catch (exception) {
      reject(exception)
    }
  })
}

function copyNunjucksFiles () {
  // Combine all the macro files into one big file and save it.
  return new Promise((resolve, reject) => {
    try {
      console.log('Copy nunjucks files - Start')

      fs.copySync(`${sourcePath}/nunjucks`, distNunjucks)
      fs.ensureDirSync(`${distNunjucks}/macros`)

      const targetMacroFilename = `${distNunjucks}/macros/barnardos.html`
      fs.writeFileSync(targetMacroFilename, '')

      walk(componentPath, (error, list) => {
        if (error) reject(error)
        const htmlFiles = list.filter(fileName => fileName.toLowerCase().endsWith('.html'))
        for (const htmlFile of htmlFiles) {
          const htmlFileContents = fs.readFileSync(htmlFile, 'utf-8')
          fs.appendFileSync(targetMacroFilename, htmlFileContents)
        }

        console.log('Copy nunjucks files - End')
        resolve()
      })
    } catch (exception) {
      reject(exception)
    }
  })
}

function copyImageFiles () {
  fs.copySync(`${__dirname}/src/images`, `${distPath}/images`)
}

Q.spawn(function * () {
  try {
    const startTime = new Date()
    clean()
    yield combineSass()
    yield copySassFiles()
    yield compileSass()
    yield copyNunjucksFiles()
    copyImageFiles()
    const endTime = new Date()
    const timeDiff = Math.round((endTime - startTime) / 60) / 1000
    console.log(`Completed in ${timeDiff} seconds`)
    process.exit(0)
  } catch (exception) {
    console.log('Something went wrong')
    console.log(exception)
    process.exit(1)
  }
})
