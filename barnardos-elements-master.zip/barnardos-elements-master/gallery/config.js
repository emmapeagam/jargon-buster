const port = process.env.PORT || 3050

module.exports = {
  env: process.env.NODE_ENV,
  port: port
}
