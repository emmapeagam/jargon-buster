const express = require('express')
const nunjucks = require('nunjucks')
const path = require('path')
const filters = require('../src/nunjucks/filters')
const config = require('./config')
const showdown = require('showdown')
const converter = new showdown.Converter()
converter.setOption('tables', true)
const fs = require('fs')
const watch = require('node-watch')
const childProcess = require('child_process')

const app = express()
const isDev = app.get('env') === 'development'

app.set('view engine', 'html')
const nunenv = nunjucks.configure([`${__dirname}/views`, `${__dirname}/../dist/nunjucks`], {
  autoescape: true,
  express: app,
  watch: isDev
})

Object.keys(filters).forEach((filterName) => {
  nunenv.addFilter(filterName, filters[filterName])
})

function runScript (scriptPath, callback) {
  childProcess.exec(`node ${scriptPath}`, function (error, stdout, stderr) {
    if (error) {
      return callback(error)
    }
    console.log(stdout)
    return callback()
  })
}

function getDirectories (srcpath) {
  return fs.readdirSync(srcpath)
    .filter(file => fs.statSync(path.join(srcpath, file)).isDirectory())
}

app.use('/images/', express.static(path.resolve(__dirname, '../dist/images')))
app.use('/javascripts/', express.static(path.resolve(__dirname, '../dist/javascripts')))
app.use('/css', express.static(path.resolve(__dirname, '../dist/css')))
app.use('/css', express.static(path.resolve(__dirname, 'css')))
app.use('/favicon.ico', express.static(path.resolve(__dirname, '../dist/images')))

/**
 * Render a gallery page
 *
 */
app.get(['/:page', '/'], (req, res, next) => {
  const page = req.params.page || 'index'
  const components = getDirectories(`${__dirname}/../src/components`)

  // Render the index page using a simple template and ignore favicon requests.
  if (page === 'index') return res.render('index', { components })
  if (page === 'favicon.ico') next()

  // Find the readme.md file for the component requested
  // Then render the markdown into nunjucks/html
  // Then render that markup through the nunjucks render process to handle any macros included
  const filename = path.resolve(__dirname, `../src/components/${page}/README.md`)
  fs.readFile(filename, 'utf8', (err, data) => {
    if (err) next(err)

    const njkSrc = `
      {% extends "index.html" %}
      {% import "macros/barnardos.html" as barnardos %}
      {% block main %}${converter.makeHtml(data)}{% endblock %}`

    try {
      const html = nunjucks.renderString(njkSrc, { components })
      res.send(html)
    } catch (error) {
      next(error)
    }
  })
})

/**
 * Watch for changes and rebuild
 */
console.log('Watching: ' + path.resolve(__dirname, '../src'))
watch(path.resolve(__dirname, '../src'), { recursive: true }, function () {
  runScript(path.resolve(__dirname, '../build.js'), function (error) {
    if (error) {
      console.log(error)
    }
  })
})

console.log(`Listening on port ${config.port}`)
app.listen(config.port)
