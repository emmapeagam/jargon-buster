const guid = require('./src/javascripts/lib/guid')
const elementstuff = require('./src/javascripts/lib/elementstuff')

module.exports = { guid, elementstuff }
