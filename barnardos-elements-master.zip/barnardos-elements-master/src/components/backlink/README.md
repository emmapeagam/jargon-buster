# Back link

A simple link to be shown at the top of a page to help the user navigate back.

## Example
<a class="back-link" href="#">Back to previous section</a>

## HTML
```
<a class="back-link" href="/">Back to previous section</a>
```
