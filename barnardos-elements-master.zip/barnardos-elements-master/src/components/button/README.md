# Button

Barnardos style buttons.

## Example
{{ barnardos.button("Simple", id="button-1", class="custom-class") }}
{{ barnardos.button("Secondary", id="button-2", variation="secondary") }}
{{ barnardos.button("Warning", id="button-3", variation="warning") }}
{{ barnardos.button("disabled", id="button-4", variation="disabled") }}

    
## HTML

```
<button class="btn">This is a button</button>
```

## Nunjucks Macros

```
barnardos.button("Simple", id="button-1", class="custom-class")
barnardos.button("Secondary", id="button-2", variation="secondary")
barnardos.button("Warning", id="button-3", variation="warning")
barnardos.button("disabled", id="button-4", variation="disabled")
```

## Parameters
| Parameter | Required | Description |
| --------- | -------- | ----------- |
| text      | Y        | The text to show on the button |
| id        | N        | If you wish the button to be assigned an ID pass it here|
| class     | N        | Pass an extra class value to add to the markup, e.g. selected |
| variation | N        | There are a range of different button styles available, which can be passed in this parameter, valid versions include *secondary*, *warning* and *disabled * |
| type      | N        | Used to specify if a button is a 'button' or 'submit' |
