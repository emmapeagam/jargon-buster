# Checkbox
Styles a regular checkbox styled to be easier for people to use

## Example
<div>
  <input id="test" type="checkbox" name="test" value="London">
  <label for="test">London</label>
</div>

## HTML
```
<div>
  <input id="test" type="checkbox" name="test" value="London">
  <label for="test">London</label>
</div>
```
