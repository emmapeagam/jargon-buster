# Error summary
Display a section at the top of a page listing the errors found further down it. This pattern helps people using devices such as screen
reader be aware of errors quicker, and allow easy navigation to errors in forms if the error is off the screen.

## Example

<div class="error-summary" role="group" aria-labelledby="error-summary-heading" tabindex="-1">
  <h1 class="heading-medium" id="error-summary-heading">
    Incomplete Information
  </h1>
  <ul class="error-summary__list">
    <li class="error-summary__item">
      <a href="#name-wrapper">Name - this field is required</a>
    </li>
  </ul>
</div>

## HTML

```
<div class="error-summary" role="group" aria-labelledby="error-summary-heading" tabindex="-1">
  <h1 class="heading-medium" id="error-summary-heading">
    Incomplete Information
  </h1>
  <ul class="error-summary__list">
    <li class="error-summary__item">
      <a href="#name-wrapper">Name - this field is required</a>
    </li>
  </ul>
</div>
```

## Macro
```
errorSummary(errors, labels)
```

## Parameters
| Parameter    | Required | Description |
| ---------    | -------- | ----------- |
| errors       | Y        | Must be in the format [{'fieldname': 'error'}]|
| labels       | N        | Key value pair of labels to use for friendly field names in the list { fieldname: label, fieldname,label} |
