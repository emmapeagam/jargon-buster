# Headings

Default sizes for headings which can also be overridden. To come, mixed headings that have sub heading styles.


# H1 .heading-xlarge
## H2 .heading-large
### H3 .heading-medium
#### H3 .heading-small
