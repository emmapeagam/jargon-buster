# Horizontal radio list

A list of options for a user to choose from, in which they are only ollowed to
make a single choice. The list is shown horizontally and generally used for short lists

## Example

<fieldset class="horizontal-radio-list">
  <legend class="horizontal-radio-list__legend">Do you want to do someting?</legend>
  <div class="horizontal-radio-list__choice">
    <input class="horizontal-radio-list__checkbox" id="yes" type="radio" name="choice" value="yes">
    <label class="horizontal-radio-list__label" for="yes">Yes</label>
  </div>
  <div class="horizontal-radio-list__choice">
    <input class="horizontal-radio-list__checkbox" id="no" type="radio" name="choice" value="no">
    <label class="horizontal-radio-list__label" for="no">No</label>
  </div>
</fieldset>

<fieldset class="horizontal-radio-list horizontal-radio-list--has-error">
  <legend class="horizontal-radio-list__legend">
    Do you want to do someting?
    <span class="horizontal-radio-list__hint">Try making a selection</span>
    <span class="horizontal-radio-list__error-message">You must select an option.</span>
  </legend>
  <div class="horizontal-radio-list__choice">
    <input class="horizontal-radio-list__checkbox" id="yes" type="radio" name="choice" value="yes">
    <label class="horizontal-radio-list__label" for="yes">Yes</label>
  </div>
  <div class="horizontal-radio-list__choice">
    <input class="horizontal-radio-list__checkbox" id="no" type="radio" name="choice" value="no">
    <label class="horizontal-radio-list__label" for="no">No</label>
  </div>
</fieldset>

## HTML
```
<fieldset class="horizontal-radio-list">
  <legend class="horizontal-radio-list__legend">Do you want to do someting?</legend>
  <div class="horizontal-radio-list__choice">
    <input class="horizontal-radio-list__checkbox" id="yes" type="radio" name="choice" value="yes">
    <label class="horizontal-radio-list__label" for="yes">Yes</label>
  </div>
  <div class="horizontal-radio-list__choice">
    <input class="horizontal-radio-list__checkbox" id="no" type="radio" name="choice" value="no">
    <label class="horizontal-radio-list__label" for="no">No</label>
  </div>
</fieldset>
```

## Nunjucks macro
```
barnardos.horizontalradiolist('choice', options=options, value=value, label='Make a choice')
```

## Parameters
| Parameter | Required | Description |
| --------- | -------- | ----------- |
| name      | Y        | The text to use for the inputs |
| options   | Y        | An array of objects containing a value and label, e.g. [{ value: 'yes', label: 'Yes'}] |
| value     | N        | The current selected value or no value passed if no value selected |
| label     | Y        | The label to display above the questions, this will be shown in a legend |
| hint      | N        | An optional message to display below a label. This can give further explanation of the questin asked |
| id        | N        | If you wish the button to be assigned an ID pass it here |
| class     | N        | Pass an extra class value to add to the markup, e.g. selected |
| error     | N        | If an error needs to be shown, provide it here, the component will indicate their in an error and display the message |
