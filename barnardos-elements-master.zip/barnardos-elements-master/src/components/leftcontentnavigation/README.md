# Left content navigation

A left navigation often used to navigate through a long document. For an example, 
look on the left of this page.
