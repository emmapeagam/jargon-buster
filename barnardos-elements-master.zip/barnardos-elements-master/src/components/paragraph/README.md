# Paragraph styles

<p class="text-lede">A large paragraph style to use at the top of a page for an introduction</p>

<p>A regular paragraph</p>

## HTML
```
<p class="text-lede">A large paragraph style to use at the top of a page for an introduction</p>
<p>A regular paragraph</p>
```
