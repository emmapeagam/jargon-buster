# Radio buttons
Styles a regular radio button to be easier for people to use

## Example
<div>
  <input id="test" type="radio" name="test" value="yes">
  <label for="test">Yes</label>
</div>

## HTML
```
<div>
  <input id="test" type="radio" name="test" value="yes">
  <label for="test">Yes</label>
</div>
```
