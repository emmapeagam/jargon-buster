# Tables

Default styles for tables

## Example 
| Name | Age | Region |
| -----| --- | ------ |
| Fred | 43  | North West |
