# Textarea

A traditional textarea, with a label above a text rea, space for a 'hint' and errors shown if there are any.

## Example

{{ barnardos.textarea('address', label='Address', value='10 The Road', hint='Enter your addres') }}<br/>
{{ barnardos.textarea('notes', label='Notes', value='Fred', error="Enter something") }}

## HTML
```
<div class="textarea textarea--has-error " id="notes-wrapper">
  <label class="textarea__label textarea__label--bold" for="notes">
    Notes
    <span class="textarea__error-message">Enter something</span>
  </label>
  <textarea id="notes" class="textarea__input" name="notes" type="">Fred</textarea>
</div>
```


## Macro
  textfield('name', label='Name', value='Fred', hint='Enter your name', error="Enter a unique name")


## Parameters
| Parameter | Required | Description |
| --------- | -------- | ----------- |
| name      | Y        | The name to use for the field |
| value     | N        | The value for the field |
| label     | Y        | The label to display above the text area |
| hint      | N        | An optional message to display below a label. This can give further explanation of the question asked |
| id        | N        | If you wish the field to be assigned an ID pass it here |
| class     | N        | Pass an extra class value to add to the markup, e.g. selected |
| error     | N        | if there is an error message associated to a field, show it here. |
