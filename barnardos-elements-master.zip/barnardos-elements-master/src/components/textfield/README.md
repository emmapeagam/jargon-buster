# Textfield

A traditional textfield, with a label above a text box, space for a 'hint' and errors shown if there are any.

## Example

{{ barnardos.textfield('name', label='Name', value='Fred', hint='Enter your name') }}<br/>
{{ barnardos.textfield('name', label='Name', value='Fred', hint='Enter your name', error="Enter a unique name") }}

## HTML
```
<div class="textfield " id="name-wrapper">
  <label class="textfield__label textfield__label--bold" for="name">
    Name
    <span class="textfield__hint">Enter your name</span>
  </label>
  <input id="name" class="textfield__input" name="name" type="text" value="Fred">
</div>

<div class="textfield textfield__has-error " id="name-wrapper">
  <label class="textfield__label textfield__label--bold" for="name">
    Name
    <span class="textfield__hint">Enter your name</span>
    <span class="textfield__error-message">Enter a unique name</span>
  </label>
  <input id="name" class="textfield__input" name="name" type="text" value="Fred">
</div>
```

## Macro
```
textfield('name', label='Name', value='Fred', hint='Enter your name', error="Enter a unique name")
```

## Parameters
| Parameter    | Required | Description |
| ---------    | -------- | ----------- |
| name         | Y        | The name to use for the field |
| value        | N        | The value for the field |
| label        | Y        | The label to display above the text field |
| hint         | N        | An optional message to display below a label. This can give further explanation of the question asked |
| id           | N        | If you wish the field to be assigned an ID pass it here |
| class        | N        | Pass an extra class value to add to the markup, e.g. selected |
| error        | N        | If there is an error message associated to a field, show it here. |
| autocomplete | N        | Defaults to true. If set to false this allows disabling browser autocomplete for fields |
| autofocus    | N        | Defaults to false. This can be set tue to add an autofocus attribute to the input control |
| type         | N        | Defaults to 'text'. If you wish to set the field to be a type other than text, provide it here, usefull for password fields |
