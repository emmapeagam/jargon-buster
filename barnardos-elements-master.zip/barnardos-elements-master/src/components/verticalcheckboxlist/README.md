#Vertical checkbox list

A list of options for a user to choose from, in which they can select more than one.
The list is shown vertically, which is best suited to long lists or variable length lists.
Try and keep lists to no more than 7 or 8 items. If your list is longer then consider a dropdown

## Example

<fieldset class="vertical-checkbox-list">
  <legend class="vertical-checkbox-list__legend">
    How many?
    <span class="vertical-checkbox-list__hint">{{hint}}</span>
  </legend>
  <div class="vertical-checkbox-list__choice">
    <input class="vertical-checkbox-list__checkbox" id="one" type="checkbox" name="choice" value="one">
    <label class="vertical-checkbox-list__label" for="one">One</label>
  </div>
  <div class="vertical-checkbox-list__choice">
    <input class="vertical-checkbox-list__checkbox" id="two" type="checkbox" name="choice" value="two">
    <label class="vertical-checkbox-list__label" for="two">Two</label>
  </div>
  <div class="vertical-checkbox-list__choice">
    <input class="vertical-checkbox-list__checkbox" id="three" type="checkbox" name="choice" value="three">
    <label class="vertical-checkbox-list__label" for="three">Three</label>
  </div>
</fieldset>

<fieldset class="vertical-checkbox-list vertical-checkbox-list--has-error">
  <legend class="vertical-checkbox-list__legend">
    How many?
    <span class="vertical-checkbox-list__hint">Pick something</span>
    <span class="horizontal-radio-list__error-message">You must select an option.</span>
  </legend>
  <div class="vertical-checkbox-list__choice">
    <input class="vertical-checkbox-list__checkbox" id="one" type="checkbox" name="choice" value="one">
    <label class="vertical-checkbox-list__label" for="one">One</label>
  </div>
  <div class="vertical-checkbox-list__choice">
    <input class="vertical-checkbox-list__checkbox" id="two" type="checkbox" name="choice" value="two">
    <label class="vertical-checkbox-list__label" for="two">Two</label>
  </div>
  <div class="vertical-checkbox-list__choice">
    <input class="vertical-checkbox-list__checkbox" id="three" type="checkbox" name="choice" value="three">
    <label class="vertical-checkbox-list__label" for="three">Three</label>
  </div>
</fieldset>


## HTML
```
<fieldset class="vertical-checkbox-list">
  <legend class="vertical-checkbox-list__legend">
    {{label}}
    <span class="vertical-checkbox-list__hint">{{hint}}</span>
  </legend>
  <div class="vertical-checkbox-list__choice">
    <input class="vertical-checkbox-list__checkbox" id="one" type="checkbox" name="choice" value="one">
    <label class="vertical-checkbox-list__label" for="one">One</label>
  </div>
  <div class="vertical-checkbox-list__choice">
    <input class="vertical-checkbox-list__checkbox" id="two" type="checkbox" name="choice" value="two">
    <label class="vertical-checkbox-list__label" for="two">Two</label>
  </div>
  <div class="vertical-checkbox-list__choice">
    <input class="vertical-checkbox-list__checkbox" id="three" type="checkbox" name="choice" value="three">
    <label class="vertical-checkbox-list__label" for="three">Three</label>
  </div>
</fieldset>
```

## Nunjucks macro
```
barnardos.verticalcheckboxlist('choice', options=options, value=value, label='Make a choice')
```

## Parameters
| Parameter | Required | Description |
| --------- | -------- | ----------- |
| name      | Y        | The text to use for the inputs |
| options   | Y        | An array of objects containing a value and label, e.g. [{ value: 'yes', label: 'Yes'}] |
| values    | N        | The current selected values or no value passed if no value selected |
| label     | Y        | The label to display above the questions, this will be shown in a legend |
| hint      | N        | An optional message to display below a label. This can give further explanation of the questin asked |
| id        | N        | If you wish the button to be assigned an ID pass it here |
| class     | N        | Pass an extra class value to add to the markup, e.g. selected |
| error     | N        | If there is an error message associated to a field, show it here. |
