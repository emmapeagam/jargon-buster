#Vertical radio list

A list of options for a user to choose from, in which they can select only one.
The list is shown vertically, which is best suited to long lists or variable length lists.
Try and keep lists to no more than 7 or 8 items. If your list is longer then consider a dropdown

## Example

<fieldset class="vertical-radio-list vertical-radio-list--has-error">
  <legend class="vertical-radio-list__legend">
    Pick an option
    <span class="vertical-radio-list__hint">Try clicking on one</span>
    <spam class="vertical-radio-list__error-message">Something is wrong
  </legend>
  <div class="vertical-radio-list__choice">
    <input class="vertical-radio-list__radio" id="one" type="radio" name="choice" value="one">
    <label class="vertical-radio-list__label" for="one">One</label>
  </div>
  <div class="vertical-radio-list__choice">
    <input class="vertical-radio-list__radio" id="two" type="radio" name="choice" value="two">
    <label class="vertical-radio-list__label" for="two">Two</label>
  </div>
  <div class="vertical-radio-list__choice">
    <input class="vertical-radio-list__radio" id="three" type="radio" name="choice" value="three">
    <label class="vertical-radio-list__label" for="three">Three</label>
  </div>
</fieldset>

## HTML
```
<fieldset class="vertical-radio-list">
  <legend class="vertical-radio-list__legend">
    {{label}}
    <span class="vertical-radio-list__hint">{{hint}}</span>
  </legend>
  <div class="vertical-radio-list__choice">
    <input class="vertical-radio-list__radio" id="one" type="radio" name="choice" value="one">
    <label class="vertical-radio-list__label" for="one">One</label>
  </div>
  <div class="vertical-radio-list__choice">
    <input class="vertical-radio-list__radio" id="two" type="radio" name="choice" value="two">
    <label class="vertical-radio-list__label" for="Two">Two</label>
  </div>
  <div class="vertical-radio-list__choice">
    <input class="vertical-radio-list__radio" id="three" type="radio" name="choice" value="three">
    <label class="vertical-radio-list__label" for="three">Three</label>
  </div>
</fieldset>
```

## Nunjucks macro
```
barnardos.verticalradiolist('choice', options=options, value=value, label='Make a choice')
```

## Parameters
| Parameter | Required | Description |
| --------- | -------- | ----------- |
| name      | Y        | The text to use for the inputs |
| options   | Y        | An array of objects containing a value and label, e.g. [{ value: 'yes', label: 'Yes'}] |
| values    | N        | The current selected values or no value passed if no value selected |
| label     | Y        | The label to display above the questions, this will be shown in a legend |
| hint      | N        | An optional message to display below a label. This can give further explanation of the questin asked |
| id        | N        | If you wish the button to be assigned an ID pass it here |
| class     | N        | Pass an extra class value to add to the markup, e.g. selected |
